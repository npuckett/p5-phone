---
name: p5-phone
description: "Use when generating p5-phone examples or answering questions about p5-phone APIs: mobile sensors, device orientation, accelerometer, gyroscope, touch, microphone, p5.sound, speech recognition, PhoneCamera, ML5 camera mapping, vibration, torch/flashlight, NFC, Bluetooth BLE, Share multi-user PartyServer rooms, GPS/geolocation, geoDistance/geoInPolygon, screen wake lock (keep the screen on), lockGestures, enablePermissionsTap, enableHardwareTap, arbitrary hardware combinations, mobile browser permissions, p5.js 2 compatibility."
argument-hint: "Describe the p5-phone example or API question"
---

# p5-phone: Mobile Hardware for p5.js

p5-phone is a single-file helper library that gives p5.js sketches access to mobile phone hardware — motion sensors, microphone, sound, speech, camera (with ML5 coordinate mapping), vibration, torch/flashlight, NFC, GPS/geolocation, Bluetooth LE, and multi-user Share rooms — plus mobile gesture locking, browser-permission activation UI, and an on-screen debug console. Current version: **1.15.4**.

It works in **both p5.js 1.x and 2.x** (auto-detected at runtime). Every public function is attached to `window` (global mode) and mirrored on `p5.prototype` (instance mode), so you call them as bare globals like `lockGestures()` and `enableGyroTap()`.

**Pair this with the `p5js-2x` skill.** p5-phone only unlocks the hardware and hands you *p5's own* globals and objects; the p5.js 2.x language patterns around them (async asset loading, the unified pointer/touch model, renamed APIs) live in the `p5js-2x` skill. Load both when writing phone sketches — and read the next section before writing any hardware code.

## When to use this skill

Use it whenever the request involves a p5-phone sketch, mobile p5.js hardware interaction, or an explanation of how p5-phone works: device orientation / accelerometer / gyroscope, touch, microphone / p5.sound, speech recognition, `PhoneCamera` and ML5 mapping, vibration, torch/flashlight, NFC, GPS/geolocation (`geoRead`, `geoDistance`, `geoInPolygon`), Bluetooth BLE, Share multi-user rooms (`shareSetup`, `shared`/`me`/`guests`), keeping the screen on (Screen Wake Lock), `lockGestures`, `enablePermissionsTap` / `enableHardwareTap`, arbitrary hardware combinations, mobile browser permissions, or p5.js 2 compatibility.

## Quick Start

For generated examples, produce a complete `index.html` **and** `sketch.js` unless the user asks for a single file or snippet.

HTML baseline (p5.js 2-compatible):

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mobile p5.js App</title>
  <style>
    body { margin: 0; padding: 0; overflow: hidden; }
  </style>
  <script src="https://cdn.jsdelivr.net/npm/p5@2.2.3/lib/p5.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/p5.js-compatibility@0.2.0/src/preload.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/p5-phone@1.15.4/dist/p5-phone.min.js"></script>
</head>
<body>
  <script src="sketch.js"></script>
</body>
</html>
```

Add p5.sound **only** when the sketch uses microphone levels, oscillators, audio input, sound output, or speech. Place it after p5 and before `p5-phone`/`sketch.js`:

```html
<script src="https://cdn.jsdelivr.net/npm/p5.sound@0.3.0/dist/p5.sound.min.js"></script>
```

Minimal sketch (`sketch.js`):

```javascript
function setup() {
  createCanvas(windowWidth, windowHeight);
  lockGestures();
  angleMode(DEGREES); // rotationX/Y/Z in degrees. p5 uses radians unless told
  enableGyroTap('Tap to enable motion sensors');
}

function draw() {
  background(20);
  if (window.sensorsEnabled) {
    // rotationX / rotationY / rotationZ are p5.js built-ins, live once sensorsEnabled is true.
    fill(0, 180, 255);
    circle(width / 2 + rotationY * 4, height / 2 + rotationX * 4, 80);
  } else {
    fill(255);
    textAlign(CENTER, CENTER);
    text('Waiting for sensors', width / 2, height / 2);
  }
}

function mousePressed() {
  return false; // let p5-phone's gesture handling manage the touch
}
```

## Golden Rules

1. **Call `lockGestures()` in every mobile sketch `setup()`.** It blocks pull-to-refresh, swipe-back, pinch-zoom, double-tap zoom, long-press menus, and overscroll so the canvas behaves like an app.
2. **Request every permission from a user gesture.** iOS grants sensitive APIs only during *transient user activation* (a tap/click). Never auto-request on page load — use an `enable*` activation UI.
3. **Gate all hardware reads behind the matching `window.*Enabled` flag** (`sensorsEnabled`, `micEnabled`, `bleConnected`, etc.). Reading before permission returns stale/undefined data. Write the gate as a positive `if (window.sensorsEnabled) { … }` around the code that reads the hardware, not a flipped early return (`if (!window.sensorsEnabled) return;`).
4. **Use `mousePressed` / `mouseDragged` / `mouseReleased`, not p5 1.x `touchStarted` / `touchMoved` / `touchEnded`.** The mouse callbacks fire for both mouse and touch in p5.js 1.x and 2.x; the touch callbacks are removed/no-ops in p5.js 2.
5. **Serve over HTTPS** (or `localhost`). Sensors, mic, camera, NFC, BLE, GPS, and torch all require a secure context on mobile.
6. **Need several hardware features from one tap? Use a single combined call** — `enablePermissionsTap(['gyro', 'torch'])` — not several single-permission binds on the same gesture. One call keeps iOS transient activation intact and fires `userSetupComplete()` once.
7. **Use exactly one activation style per permission need** unless the user explicitly asks to compare styles.
8. **One `enable*` call at a time.** Each `enable*` call removes the button, overlay or banner of any earlier one, so `enableGyroTap()` followed by `enableBleButton()` leaves only the BLE button and motion never starts. Combine permissions in one `enablePermissions*` call. BLE and Share are not tokens there: start them from `userSetupComplete()` (see [Combining features](#combining-features)).

## Use p5.js built-ins — do not reimplement them

The most common failure mode is a model **hand-rolling hardware plumbing** (a raw `DeviceOrientationEvent` listener, a `touchstart` handler, a Web Audio graph, a manual asset loader) instead of reading the values p5-phone and p5.js already provide. p5-phone deliberately surfaces everything through *p5's own* globals and objects. For each concern below, use the p5 built-in — never a bespoke equivalent:

| p5-phone concern | Use these p5.js built-ins (not custom code) | Notes |
| --- | --- | --- |
| Device orientation | `rotationX`, `rotationY`, `rotationZ` (+ `pRotationX/Y/Z`) | p5 globals in the current `angleMode()`: radians unless the sketch calls `angleMode(DEGREES)`. p5-phone only gates them via `sensorsEnabled` |
| Acceleration | `accelerationX/Y/Z`, `pAccelerationX/Y/Z` | p5 globals |
| How fast it is turning | `rotationX - pRotationX` (and Y, Z) each frame, or `deviceTurned()` with `turnAxis` | p5.js has **no** rotation-rate globals (see the trap below) |
| Motion events / thresholds | `deviceMoved()`, `deviceShaken()`, `setMoveThreshold()`, `setShakeThreshold()`, `deviceOrientation` | define the callbacks as globals |
| Touch / pointer input | `mousePressed()`, `mouseDragged()`, `mouseReleased()`, `mouseX`, `mouseY`, `touches[]` | p5.js 2 unifies mouse+touch under the pointer model; use `touches[]` for multitouch, and `touches.length > 0` for "a finger is down" (`mouseIsPressed` turns false when any one finger lifts). Do **not** add your own `addEventListener('touchstart', …)` |
| Drawing the camera feed | `image(cam, x, y, w, h)` + `cam.mapKeypoint()/mapBox()` | `PhoneCamera` integrates with p5's `image()`; map ML5 results with its helpers, not manual video compositing. Under the unminified p5.js 2.2.3+, p5-phone 1.15.4 and earlier log a harmless "Expected Image or Element" warning each frame; the camera still draws |
| Microphone level / analysis | `p5.AudioIn`, `p5.Amplitude`, `p5.FFT` (p5.sound) | not a raw Web Audio graph |
| Generated sound | `p5.Oscillator`, `p5.Envelope` (p5.sound) | prefer over `loadSound()` for portability |
| Loading images/audio/JSON/font | `await loadImage()/loadSound()/loadJSON()/loadFont()` in `async setup()` | p5.js 2: `load*` return Promises — no `preload()`. See the `p5js-2x` skill |
| Mapping / ranges | `map()`, `constrain()`, `lerp()` | p5 math helpers |

Two specific traps worth calling out:

- **Motion values are p5.js built-ins, not p5-phone APIs.** p5-phone only requests the *permission* and sets `window.sensorsEnabled`. The data (`rotationX`, `accelerationX`, `deviceShaken()`, …) comes straight from p5.js. Do not invent p5-phone getters for them.
- **p5.js has no rotation rate.** `rotationRateAlpha`, `rotationRateBeta` and `rotationRateGamma` are not p5 globals, in 1.x or 2.x, and p5-phone does not add them. Reading them throws a `ReferenceError` on every frame once the sensors are on, so the sketch stops drawing. For how fast the phone is turning, use the change in `rotationX/Y/Z` from `pRotationX/Y/Z` each frame (watch the wrap at ±180°), or `deviceTurned()` and `turnAxis` for a quarter turn. Only if a sketch truly needs the gyroscope's own rate, read `event.rotationRate` (it can be `null`) in a `devicemotion` listener once `window.sensorsEnabled` is true. That is the one place a listener is the right call.
- **There is no `bleValue()` getter.** Read incoming BLE data from `window.bleValues[name]` or from the `bleReceive(name, value)` callback. `bleValues` is an object keyed by characteristic name.

## Permissions model

Every hardware family exposes the same **six activation styles**. Pick one:

- **Tap** — `enable<Feature>Tap(message)` — full-screen tap overlay.
- **Button** — `enable<Feature>Button(buttonText, statusText?)` — auto-generated button.
- **Canvas** — `enable<Feature>Canvas(message)` — prompt drawn on the p5 canvas.
- **Banner** — `enable<Feature>Banner(message, position?)` — animated slide-in banner (`position` = `'top'`/`'bottom'`).
- **On (custom element)** — `enable<Feature>On(selector)` — bind activation to any existing HTML element by CSS selector. The element stays on the page; hide it in `draw()` once the flag is true (`select('#start').hide()`).
- **Minimal** — `enable<Feature>Minimal(message?)` or `enable<Feature>Minimal({ color, opacity, icon, iconColor, iconSize, message })` — bare semi-transparent overlay with a pulsing icon, no message box (v1.14.0).

Full matrix:

| Feature | Tap | Button | Canvas | Banner | Minimal | On (selector) |
| --- | --- | --- | --- | --- | --- | --- |
| Motion sensors | `enableGyroTap(msg)` | `enableGyroButton(text)` | `enableGyroCanvas(msg)` | `enableGyroBanner(msg)` | `enableGyroMinimal(msg/opts?)` | `enableGyroOn(sel)` |
| Microphone | `enableMicTap(msg)` | `enableMicButton(text)` | `enableMicCanvas(msg)` | `enableMicBanner(msg)` | `enableMicMinimal(msg/opts?)` | `enableMicOn(sel)` |
| Sound output | `enableSoundTap(msg)` | `enableSoundButton(text)` | `enableSoundCanvas(msg)` | `enableSoundBanner(msg)` | `enableSoundMinimal(msg/opts?)` | `enableSoundOn(sel)` |
| Speech | `enableSpeechTap(msg)` | `enableSpeechButton(text)` | `enableSpeechCanvas(msg)` | `enableSpeechBanner(msg)` | `enableSpeechMinimal(msg/opts?)` | `enableSpeechOn(sel)` |
| Vibration | `enableVibrationTap(msg)` | `enableVibrationButton(text)` | `enableVibrationCanvas(msg)` | `enableVibrationBanner(msg)` | `enableVibrationMinimal(msg/opts?)` | `enableVibrationOn(sel)` |
| Torch / flashlight | `enableTorchTap(msg)` | `enableTorchButton(text)` | `enableTorchCanvas(msg)` | `enableTorchBanner(msg)` | `enableTorchMinimal(msg/opts?)` | `enableTorchOn(sel)` |
| NFC | `enableNfcTap(msg)` | `enableNfcButton(text)` | `enableNfcCanvas(msg)` | `enableNfcBanner(msg)` | `enableNfcMinimal(msg/opts?)` | `enableNfcOn(sel)` |
| GPS / geolocation | `enableGeoTap(msg)` | `enableGeoButton(text)` | `enableGeoCanvas(msg)` | `enableGeoBanner(msg)` | `enableGeoMinimal(msg/opts?)` | `enableGeoOn(sel)` |
| Bluetooth (BLE) | `enableBleTap(opts?)` | `enableBleButton(opts?)` | `enableBleCanvas(opts?)` | `enableBleBanner(opts?)` | `enableBleMinimal(opts?)` | `enableBleOn(sel)` |
| Share (multi-user) | `enableShareTap(opts?)` | `enableShareButton(opts?)` | `enableShareCanvas(opts?)` | `enableShareBanner(opts?)` | `enableShareMinimal(opts?)` | `enableShareOn(sel)` |
| Camera | `enableCameraTap(msg)` | `enableCameraButton(text)` | `enableCameraCanvas(msg)` | `enableCameraBanner(msg)` | `enableCameraMinimal(msg/opts?)` | `enableCameraOn(sel)` |
| Sensors + mic | `enableAllTap(msg)` | `enableAllButton(text)` | `enableAllCanvas(msg)` | `enableAllBanner(msg)` | `enableAllMinimal(msg/opts?)` | `enableAllOn(sel)` |
| Any combination | `enablePermissionsTap(list, msg)` | `enablePermissionsButton(list, text)` | `enablePermissionsCanvas(list, msg)` | `enablePermissionsBanner(list, msg)` | `enablePermissionsMinimal(list, msg/opts)` | `enablePermissionsOn(sel, list)` |

Notes:

- `enableBle*` take an **options object** (`{ label, message, statusText, position }`), unlike the other families which take positional `(message, position)` / `(buttonText, statusText)`.
- `enableShare*` take a label string or an **options object** (same shape as `enableBle*`). Call `shareSetup({ host, room })` first; deploy [companion/P5PhoneShare](companion/P5PhoneShare/).
- `enableSensor*` is an **alias** for `enableGyro*`: the same six functions under a second name. Write `enableGyro*`, the name in the source, the README and the examples homepage. Sketches that call `enableSensor*` still work.
- `enableAll*` is shorthand for sensors + mic. For any other mix, use `enablePermissions*`.
- `enableHardware*` is an exact alias of `enablePermissions*` (all six styles). `enableFlashlight*` is an alias of `enableTorch*`.

### Combining features

`enablePermissions*` (a.k.a. `enableHardware*`) takes a list plus a message. The list can be an array or a space/comma string.

**Names for the list:** `gyro` (motion and orientation, like `enableGyroTap()`; it sets `window.sensorsEnabled`), `mic`, `sound`, `speech`, `vibration`, `torch`, `nfc`, `geo`, `camera`. Write `gyro` for motion in generated code, not the more generic `sensors`.

**Other names that work** (each means the same as one above): `motion`, `sensors`, `sensor`, `orientation`, `gyroscope`, `accelerometer` → `gyro`; `microphone`, `audioin` → `mic`; `audio`, `audiooutput`, `output` → `sound`; `voice`, `recognition` → `speech`; `vibrate`, `haptic`, `haptics` → `vibration`; `flashlight`, `flash`, `light` → `torch`; `tag`, `tags` → `nfc`; `gps`, `location`, `geolocation` → `geo`; `video`, `webcam` → `camera`; `all` → `gyro` + `mic`.

```javascript
function setup() {
  createCanvas(windowWidth, windowHeight);
  lockGestures();
  enablePermissionsTap(['gyro', 'mic'], 'Tap to enable motion + microphone');
}

function draw() {
  if (window.sensorsEnabled && window.micEnabled) {
    // Use motion values and microphone input here.
  }
}
```

**BLE or Share as well.** `ble` and `share` are not tokens, and a second `enable*` call in `setup()` would remove the first one's UI. Start them once the first tap has worked:

```javascript
function setup() {
  createCanvas(windowWidth, windowHeight);
  lockGestures();
  bleSetup({ characteristics: [{ name: 'brightness', type: 'uint8', write: true }] });
  enableGyroTap('Tap to start');
}

function userSetupComplete() {
  // Runs after the motion tap. The Bluetooth chooser needs a tap of its own.
  enableBleButton({ label: 'Connect the lamp' });
}
```

For Share, call `shareSetup()` in `setup()` and `shareConnect()` in `userSetupComplete()`. Share needs no second tap.

## Status variables and callbacks

Read these `window.*` flags before using hardware data:

- **Motion:** `sensorsEnabled`
- **Microphone:** `micEnabled` (request ran), `micOpen` (stream really live — gate reads on this)
- **Sound:** `soundEnabled`
- **Speech:** `speechEnabled`
- **Vibration:** `vibrationEnabled`
- **Torch:** `torchEnabled`, `torchSupported`, `torchActive`, `torchError`, `torchCapability`
- **NFC:** `nfcEnabled`, `nfcStatus`, `nfcError`, `nfcTagAliases`, `lastNfcSerialNumber`, `lastNfcAlias`, `lastNfcMessage`
- **GPS:** `geoEnabled`, `geoStatus`, `geoError`, `lastGeoPosition`
- **BLE:** `bleSupported`, `bleConnected`, `bleStatus`, `bleError`, `bleDeviceName`, `bleValues`
- **Share:** `shareSupported`, `shareConnected`, `shareStatus`, `shareError`, `shareRoom`, `shareClientId`, `shareIsHost`, `shared`, `me`, `guests`
- **Camera:** `cameraEnabled`
- **Gestures:** `gesturesLocked`
- **Device:** `isMobile`, `isDesktop` (best-effort detection, set when the library loads)

Callbacks your sketch can define (p5-phone calls them if present):

- `userSetupComplete()` — fires once immediately after permissions succeed.
- `deviceMoved()`, `deviceShaken()` — p5.js motion events (available after `sensorsEnabled`).
- `nfcRead(message, serialNumber)` — a tag was read.
- `geoRead(position)` — a new GPS position arrived. `position` is a plain object: `{ latitude, longitude, accuracy, altitude, altitudeAccuracy, heading, speed, timestamp }`.
- `onGeoError(error)` — a GPS stream error after the watch started. `error.code`: 1=`PERMISSION_DENIED`, 2=`POSITION_UNAVAILABLE`, 3=`TIMEOUT`.
- `bleReceive(name, value)` — a BLE characteristic notified or was read.
- `shareReady()` — Share room welcome applied.
- `shareReceive(path, value)` — remote Share patch applied.
- `shareClosed()` / `shareHostChanged(isHost)` / `shareEvent(name, data)` — Share lifecycle and emits.

```javascript
function userSetupComplete() {
  debug('Permissions ready');
}
```

## Motion sensors

After `window.sensorsEnabled` is true, read p5.js built-ins:

- Orientation: `rotationX`, `rotationY`, `rotationZ`
- Acceleration: `accelerationX`, `accelerationY`, `accelerationZ`
- Previous frame: `pRotationX/Y/Z`, `pAccelerationX/Y/Z`. For turning speed, use `rotationX - pRotationX`. There is no `rotationRate*` in p5.js.
- Events: `deviceMoved()`, `deviceShaken()`, `deviceTurned()` (with `turnAxis`)
- Thresholds: `setMoveThreshold(value)`, `setShakeThreshold(value)`
- Orientation state: `deviceOrientation`

`rotationX/Y/Z` follow `angleMode()`, so they are radians unless the sketch calls `angleMode(DEGREES)`. Call it in `setup()` of every tilt sketch that maps tilt to pixels or compares it with degree thresholds: in radians, `rotationY * 3` moves a few pixels. In degrees, `rotationX` runs from -180 to 180, `rotationY` from -90 to 90, and `rotationZ` from 0 to 360.

On a computer with no tilt sensor, `sensorsEnabled` still turns true after the tap, and `rotationX/Y/Z` stay 0. The browser sends one empty reading there (every angle `null`); p5-phone drops it before p5 sees it.

iOS requires the sensor permission to be requested from a tap/click. Never auto-request motion permission on page load.

## Touch

Touch needs no permission. Use p5.js built-ins: `mousePressed()`, `mouseDragged()`, `mouseReleased()`, `mouseX` and `mouseY` for one finger, and `touches[]` (each with `x`, `y` and `id`) for several.

- `mouseIsPressed` turns false as soon as any one finger lifts, even with other fingers still down. In a multi-finger sketch, test `touches.length > 0` for "a finger is down".
- When the phone cancels a touch (a system swipe, too many fingers), the touch leaves `touches[]` and `mouseIsPressed` turns false, as if the finger lifted. With p5.js 2.0 to 2.3.0 (2.2.3 included), p5-phone does this and also runs `mouseReleased(e)`, with `e.type === 'pointercancel'`; on their own those versions keep the touch in `touches[]` until the page reloads. p5.js 2.3.1 and later do it themselves, without calling `mouseReleased()`.

## Microphone and sound

Include p5.sound and create `p5.AudioIn()` before enabling mic. **`mic.getLevel()` does not exist in p5.sound 0.3.x** — route the mic into a `p5.Amplitude` and read `amplitude.getLevel()`. Always `mic.disconnect()` first: every p5.sound 0.3.x node is wired to the speakers by default, so otherwise the live mic plays out loud (feedback). Gate reads on `window.micOpen` (stream really live), not `window.micEnabled` — `micEnabled` only means the request ran and is `true` even when the person denies the microphone, because p5.sound 0.3.x swallows that failure. Avoid `p5.Amplitude.setInput(mic)` before permission — p5.sound 0.3.0 can throw in p5.js 2 previews.

```javascript
let mic;
let amplitude;

function setup() {
  createCanvas(windowWidth, windowHeight);
  lockGestures();
  mic = new p5.AudioIn();
  amplitude = new p5.Amplitude();
  mic.disconnect();          // keep the live mic out of the speakers
  mic.connect(amplitude);
  enableMicTap('Tap to enable microphone');
}

function draw() {
  background(0);
  // micOpen is false while prompting, if denied, or with no input device
  if (window.micOpen) {
    const level = amplitude.getLevel();
    circle(width / 2, height / 2, 40 + level * 600);
  }
}
```

For generated audio, use `enableSoundTap()` (or `enableSoundOn(selector)`) to resume the AudioContext, then `p5.Oscillator`. Prefer generated sound over `loadSound()` unless the user provides audio assets — it is more portable in the p5 Web Editor.

The sound tap (and any tap that asks for `sound` or `mic`) also starts other engines. It calls `Tone.start()` when Tone.js is loaded, and resumes any `new AudioContext()` the sketch makes after p5-phone loads (e.g. for smplr). Don't write your own first-tap unlock listener. Combined taps such as `enablePermissionsTap(['motion', 'sound'])` start audio before the iOS motion prompt. After the first tap, any touch resumes audio the phone paused (leaving the page, locking the screen), so don't add `userStartAudio()` to `mousePressed()`. Audio paused on purpose with `userStopAudio()` or `ctx.suspend()` stays paused.

## Speech recognition

`enableSpeech*` satisfies the mobile audio/user-activation requirement and sets `window.speechEnabled`; it deliberately does **not** create a `p5.AudioIn` (which would conflict with the mic). After activation, create your own Web Speech API `SpeechRecognition` object.

## Camera and ML5 (`PhoneCamera`)

`createPhoneCamera(active = 'user', mirror = true, mode = 'fitHeight')` returns a `PhoneCamera`. The camera is not initialized until an `enableCamera*` gesture (this fixes an iOS rotation bug).

- `active`: `'user'` (front) or `'environment'` (rear).
- `mirror`: mirror the display (front cameras usually `true`).
- `mode`: `'fitHeight'`, `'fitWidth'`, `'cover'`, `'contain'`, or `'fixed'`.

```javascript
let cam;
let model;
let hands = [];

function setup() {
  createCanvas(405, 720);
  lockGestures();
  cam = createPhoneCamera('user', true, 'fitHeight');
  enableCameraTap('Tap screen to enable camera');

  cam.onReady(() => {
    // Use ml5's ready callback, not await: in a running p5 sketch, ml5.handPose()
    // returns before the model has loaded, and detectStart() then fails.
    model = ml5.handPose({ maxHands: 1, runtime: 'mediapipe', flipped: false }, () => {
      model.detectStart(cam.videoElement, gotResults);
    });
  });
}

function gotResults(results) {
  hands = results;
}
```

- **In a p5 sketch, start detection in ml5's ready callback.** `await ml5.handPose(...)` waits only when no p5 sketch is running (a three.js page, even one that loads p5 for the Web Editor). Once a p5 sketch is running, it hands back a model that is still loading, and `detectStart()` throws `Cannot read properties of null (reading 'estimateHands')`. The same goes for `ml5.faceMesh()` and `ml5.bodyPose()`.
- **Use `runtime: 'mediapipe'`.** It loads the hand and face models from jsdelivr in a second or two. ml5's default runtime fetches its models through Kaggle, which can be slow or fail.

`PhoneCamera` properties: `ready`, `video` (p5 element), `videoElement` (native `<video>` for ML5), `width`, `height`, `active`, `mirror`, `mode`, `fixedWidth`, `fixedHeight`.

Coordinate-mapping methods (video space → display space, mirror-aware):

- `cam.onReady(callback)` — safe point to start ML5.
- `cam.getDimensions()` → `{ x, y, width, height, scaleX, scaleY }`.
- `cam.mapPoint(x, y)` → `{ x, y }`.
- `cam.mapKeypoint(keypoint)` / `cam.mapKeypoints(keypoints)`.
- `cam.mapBox(box)` / `cam.mapBoxes(boxes)`.
- `cam.remove()` — stop and clean up the camera.

Set ML5 `flipped: false` when available — `PhoneCamera` already handles mirroring and coordinate mapping, so pass raw ML5 results through the `map*` helpers.

For ml5 1.x with p5.js 2 (2.2.3, 2.3.2), add the preload-counter polyfill before loading ml5, and pin the ml5 version:

```html
<script src="https://cdn.jsdelivr.net/npm/p5@2.2.3/lib/p5.js"></script>
<script src="https://cdn.jsdelivr.net/npm/p5.js-compatibility@0.2.0/src/preload.js"></script>
<script>
  p5.prototype._incrementPreload ||= function() {};
  p5.prototype._decrementPreload ||= function() {};
</script>
<script src="https://cdn.jsdelivr.net/npm/ml5@1.4.0/dist/ml5.min.js"></script>
```

For Three.js pages that use ML5 but are not p5 sketches, put p5, the compatibility shim, the preload-counter polyfill, and ml5 in the document `<head>` so p5 Web Editor preview injection does not run before p5 exists.

## NFC

Android Chrome only, requires HTTPS. Compatible with widely available NFC Type 2 tags — NTAG213, NTAG215, NTAG216 — and any NDEF-formatted tag.

```javascript
function setup() {
  createCanvas(windowWidth, windowHeight);
  lockGestures();
  enableNfcTap('Tap to enable NFC');
}

function nfcRead(message, serialNumber) {
  setNfcTagAlias(serialNumber, 'example-tag');
  debug('Read NFC tag: ' + serialNumber);
}

function draw() {
  background(20);
  if (isNfcTag('example-tag')) {
    background(0, 120, 255);
  }
}
```

Helpers: `setNfcTagAlias(serialNumber, alias)`, `getNfcTagAlias(serialNumber?)` (defaults to `window.lastNfcSerialNumber`), `isNfcTag(aliasOrSerialNumber)`, `stopNfc()`. Track state via `window.nfcStatus` (`idle`/`starting`/`requesting-permission`/`scanning`/`tag-read`/`permission-denied`/`unsupported`/`secure-context-required`/`error`/`stopped`) and `window.nfcError`. Inside an iframe (the p5.js Web Editor) Web NFC cannot run: the status is `unsupported` and `nfcError` says to open the sketch on its own page.

## GPS / geolocation

Cross-platform (iOS Safari + Android Chrome), requires HTTPS. Builds on `navigator.geolocation` — the only well-supported API in 2026. **Coarse by default** (battery-friendly, ~50-100m); opt into real GPS via `setGeoOptions({ enableHighAccuracy: true })` *before* enabling. Cold start can take 5-30s.

```javascript
function setup() {
  createCanvas(windowWidth, windowHeight);
  lockGestures();
  // Optional: real GPS (~5-10m outdoors). Omit for coarse default.
  setGeoOptions({ enableHighAccuracy: true });
  enableGeoTap('Tap to enable GPS');
}

function draw() {
  background(20);
  const pos = window.lastGeoPosition;
  if (pos) {
    text(pos.latitude.toFixed(5) + ', ' + pos.longitude.toFixed(5), width / 2, height / 2);
  } else if (window.geoStatus === 'requesting-permission') {
    text('Acquiring GPS…', width / 2, height / 2);
  }
}

function geoRead(position) {
  // { latitude, longitude, accuracy, altitude, altitudeAccuracy, heading, speed, timestamp }
}
```

Helpers: `setGeoOptions({ enableHighAccuracy?, timeout?, maximumAge? })` (call before `enableGeo*`), `getGeoPosition()` (sync last position or `null`), `geoDistance(lat1, lon1, lat2, lon2, units)` (Haversine; `'m'` default, `'km'`, `'mi'`), `geoInPolygon([{lat,lon},…], {lat,lon})` (ray-casting geofence test), `stopGeo()`. Track state via `window.geoStatus` (`idle`/`requesting-permission`/`active`/`permission-denied`/`unsupported`/`secure-context-required`/`error`/`stopped`) and `window.geoError`. Optional error callback: `onGeoError(error)`.

Gotchas: iOS does not track in background/locked screen; in-app browsers (Instagram/Facebook) usually fail — tell users to open in Safari; `navigator.permissions.query({name:'geolocation'})` always returns `'prompt'` on Safari (WebKit bug), so don't gate UI on it.

## Bluetooth Low Energy (BLE)

Web Bluetooth exchanges typed values with Arduino-class peripherals. Call `bleSetup()` in `setup()` before any connect helper; connect from a user gesture via `enableBle*`.

Platform support:
- Chrome/Edge on Android and desktop over HTTPS (or localhost).
- iOS Safari/Chrome: not supported — use the **Bluefy** browser app.
- Embedded iframes need `allow="bluetooth"`.

```javascript
function setup() {
  createCanvas(windowWidth, windowHeight);
  lockGestures();

  bleSetup({
    namePrefix: 'p5phone',      // optional device-name filter
    autoReconnect: true,        // optional
    characteristics: [
      { name: 'temp', type: 'float', notify: true },
      { name: 'brightness', type: 'uint8', write: true }
    ]
  });

  enableBleButton({ label: 'Connect device' });
  showDebug();
}

function draw() {
  background(20);
  if (bleConnected) {
    text('temp: ' + (bleValues.temp ?? '—'), 20, 40);
  }
}

function mousePressed() {
  if (bleConnected) {
    bleWrite('brightness', floor(map(mouseX, 0, width, 0, 255)));
  }
  return false;
}

function bleReceive(name, value) {
  debug('BLE ' + name + ' = ' + value);
}
```

`bleSetup(config)` fields:
- `serviceUUID` — hyphenated 128-bit UUID; defaults to the P5PhoneBLE service if omitted.
- `namePrefix` — optional device-name filter.
- `autoReconnect` — optional boolean.
- `characteristics` — required array of `{ name, type, read?, write?, notify?, uuid? }`. Each needs at least one of `read`/`write`/`notify`. Omit `uuid` to auto-derive it from the service UUID and declaration order (must match the P5PhoneBLE Arduino side). Names must be unique.

Valid `type` values: `bool`, `int8`, `uint8`, `int16`, `uint16`, `int32`, `uint32`, `float`, `double`, `string`, `bytes`. Numeric types use little-endian byte order.

Lifecycle and I/O:
- `enableBle*(options)` — connect from a user gesture.
- `bleConnect()` / `bleDisconnect()` — programmatic connect/disconnect (connect still needs a gesture).
- `bleRead(name)` — async; reads and decodes a characteristic, updates `window.bleValues[name]`, returns the value.
- `bleWrite(name, value, opts?)` — async; `opts.ack === false` uses write-without-response (default is write-with-response). String writes over ~20 bytes may truncate on default-MTU peripherals.
- `isBleSupported()` — boolean.
- `bleReceive(name, value)` — your callback, fired on notify and on read.

`window.bleStatus` progresses through `idle`/`connecting`/`connected`/`requesting`/`disconnected`/`error`/`unsupported`. `bleValues` is not cleared on disconnect (sketches keep rendering last-known values).

## Share (multi-user / PartyServer)

Sync JSON variables across phones in one room. Client API mirrors BLE (`shareSetup` → gesture connect → status globals). Backend is [companion/P5PhoneShare](companion/P5PhoneShare/) (Cloudflare PartyServer Durable Object) — **each project deploys its own free worker**.

**Agent: launch a server for this user’s project** (student, artist, or class):

1. Confirm they have (or can create) a free Cloudflare account
2. `cd companion/P5PhoneShare && npm install`
3. `npx wrangler login` (interactive — ask the user to finish in the browser if needed)
4. `npx wrangler deploy` — capture the printed `https://….workers.dev` URL
5. Put that URL in **their** sketch: `shareSetup({ host: 'https://…', room: '…' })`
6. Explain: the worker stays up without their laptop; friends join the sketch URL / QR (`showDesktopQr()`), and do not need to deploy unless they want their own project server
7. Do **not** invent or reuse a public shared relay URL

```javascript
function setup() {
  createCanvas(windowWidth, windowHeight);
  lockGestures();
  shareSetup({
    host: 'https://YOUR.workers.dev', // from wrangler deploy — this project’s server
    room: 'my-game',
    app: 'final-project',
    shared: { score: 0 },
    me: { x: 0.5, y: 0.5, name: 'a' }
  });
  enableShareTap({ label: 'Tap to join room' });
  showDesktopQr(); // invite link for friends; also updates the address bar
}
```

Functions: `shareSetup(config)`, `enableShare*` (or `shareConnect()` from a gesture), `shareDisconnect()`, `shareSet(path, v)` / `shareSetMe(path, v)`, `shareEmit(name, data?)` (one-shot room event, received in `shareEvent(name, data)`, not stored, not echoed to the sender), `getShareJoinUrl()`, `isShareSupported()`.

Join URL shape: `?shareHost=https://….workers.dev&room=my-game&app=final-project`  
Helpers: `getShareJoinUrl()`, `showDesktopQr({ share: false })` to opt out.  
Full path: `companion/P5PhoneShare/README.md`.

Rules:
- Values must be JSON-serializable plain data (no functions, DOM, `NaN`, class instances).
- Mutate `shared` / `me` like objects (arrays too: `shared.list.push(x)`), or use `shareSet('pos.x', v)` / `shareSetMe(...)`.
- Writing `me.x = mouseX` every frame is fine: unchanged values are not sent and changes are batched (`shareSetup({ sendInterval })`, default 50 ms). Do not add your own throttling.
- Last write wins, and all phones converge on the worker's value. Two simultaneous `shared.score += 1` taps count once: for counts, keep a per-phone tally in `me` and sum `guests`, or let `shareIsHost` own the value.
- On phones the page leaves the room while hidden (locked screen) and rejoins when visible, keeping `me` (`disconnectWhenHidden`, default on mobile). `shared` edits made while disconnected are replaced by the room state on rejoin.
- `guests` is read-mostly (other players' `me` snapshots); mutating it does not sync.
- `shareIsHost` is true for the first client to join; when the host leaves, the lexicographically first remaining client takes over.
- After updating p5-phone, redeploy the worker (`npx wrangler deploy`): 1.14.0 speaks protocol v2, and a mismatch shows as `shareError` "Unsupported protocol version".
- Wire protocol: see `companion/P5PhoneShare/PROTOCOL.md`.
- Roadmap: localStorage host memory, short room codes, one-click deploy, adapters.

## Vibration

Use `enableVibration*` before `vibrate(pattern)`. iOS does not support the Vibration API — write examples that still show useful feedback when `window.vibrationEnabled` is false.

```javascript
function mousePressed() {
  if (window.vibrationEnabled) {
    vibrate([40, 30, 80]); // ms on / off / on, or a single number
  }
  return false;
}
```

`stopVibration()` cancels an ongoing pattern.

## Torch / flashlight

Works on iPhone (iOS 17.4 or later) and Android Chrome. Requires HTTPS and works through a rear-camera stream. Enable with `enableTorch*()` (or `enablePermissions*(['torch'])`), then control the light:

- `torchOn()`, `torchOff()`, `toggleTorch()`, `setTorch(enabled)` (async), `stopTorch()`, `isTorchSupported()`.
- Flashlight aliases: `enableFlashlight*`, `flashlightOn()`, `flashlightOff()`, `toggleFlashlight()`, `setFlashlight()`, `stopFlashlight()`.
- Runtime check: `isTorchSupported()` (or `window.torchSupported`) after enabling. It is `false` on phones with no rear flash, on iOS before 17.4, and on desktop. Use it to show a fallback, such as a bright screen.

```javascript
function setup() {
  createCanvas(windowWidth, windowHeight);
  lockGestures();
  enablePermissionsTap(['gyro', 'torch'], 'Tap to enable shake flashlight');
}

async function deviceShaken() {
  if (window.sensorsEnabled && window.torchEnabled) {
    await toggleTorch();
  }
}
```

Keep flashing pulses slow and short, avoid rapid strobing, and call `torchOff()` or `stopTorch()` when the effect ends.

## Screen Wake Lock (keep the screen on)

Only touches reset the phone's auto-lock timer, so a sketch driven by motion, sound, GPS, or BLE goes dark after about 30 seconds. Keep the screen on with the browser's own Screen Wake Lock API. **It is not a p5-phone feature:** there is no `keepScreenOn()`, no `enableWakeLock*()`, and no `wakelock` token for `enablePermissions*`. Do not invent them; call `navigator.wakeLock` directly.

```javascript
let wakeLock = null;
let wantAwake = false;

function setup() {
  createCanvas(windowWidth, windowHeight);
  lockGestures();
  // The browser drops the lock while the page is hidden. Ask again when it's back.
  document.addEventListener('visibilitychange', () => {
    if (wantAwake && document.visibilityState === 'visible') requestWakeLock();
  });
}

async function requestWakeLock() {
  try {
    wakeLock = await navigator.wakeLock.request('screen');
  } catch (err) {
    debugWarn('Wake lock refused: ' + err.message); // power saving, low battery, blocked iframe
  }
}

function mouseReleased() {
  const awake = wakeLock !== null && !wakeLock.released;
  if ('wakeLock' in navigator && !awake) {
    wantAwake = true;
    requestWakeLock();
  }
  return false;
}
```

- **Request from `mouseReleased()`.** iOS Safari refuses the first request without a user gesture, and a touch only counts as one when the finger lifts, so `mousePressed()` is too early. `userSetupComplete()` is too late: it runs after the permission prompts, when iOS may no longer count the tap. Chrome needs no gesture.
- **Request again on `visibilitychange`.** The lock is released whenever the page is hidden (another app, another tab, the side button) and never comes back by itself. On iOS, only the first request needs a tap.
- Wrap `request()` in `try`/`catch`: power saving and low battery can refuse or drop the lock. Check `wakeLock.released` (or listen for the sentinel's `release` event) rather than assuming the lock is still held.
- HTTPS or `localhost` only; `'wakeLock' in navigator` is `false` otherwise.
- It fails in the p5.js Web Editor with `NotAllowedError`, because the preview iframe lacks `allow="screen-wake-lock"`. Host the sketch on its own page (GitHub Pages works).
- It only keeps the screen on. It can't change the phone's auto-lock setting or brightness, turn on a screen that is off, or keep the sketch running in the background.
- Support: Chrome and Edge, Safari 16.4+ on iOS (Home Screen web apps from 18.4), Firefox 126+.

Example: `examples/Phone Sensor Examples/wakelock/01_keep_screen_on/`.

## lockGestures reference

```javascript
lockGestures(options?)
```

`options`:
- `mode` — `'fullscreen'` (default) or `'embedded'`.
- `element` — target element for embedded mode (defaults to the first `<canvas>`).
- `warnBeforeLeave` — show a leave-confirmation prompt (default `false`).
- `trapHistory` — trap back/forward navigation (default `true` in fullscreen, `false` in embedded).

Use bare `lockGestures()` for full-screen mobile sketches. Use `lockGestures({ mode: 'embedded', element: canvas })` for a canvas embedded in a scrollable, multi-section page — it scopes gesture blocking to that canvas so the rest of the page still scrolls. `unlockGestures()` restores the saved handlers, listeners, and styles. `window.gesturesLocked` reflects the current state.

Form controls work under either mode: `createInput()`, `createSelect()`, `createCheckbox()`, `createSlider()`, textareas, `contenteditable` elements and labels take taps, clicks, focus and typing. The sketch's own `mousePressed()` can keep `return false`. So a sketch with a text field still calls plain `lockGestures()`; it does not need embedded mode for that. Up to p5-phone 1.15.4, `lockGestures()` cancelled presses on form controls in both modes and a text field never took focus. In a sketch pinned to 1.15.4 or earlier, keep each field's presses away from p5:

```javascript
// p5-phone 1.15.4 and earlier only
for (const type of ['pointerdown', 'mousedown', 'touchstart', 'touchend']) {
  field.elt.addEventListener(type, (e) => e.stopPropagation());
}
```

Caveat: p5 touch/mouse callbacks are snapshotted when gestures lock. If you assign `window.mousePressed = ...` *after* `lockGestures()`, you replace p5-phone's wrapper. Define your callbacks before locking, or reassign is fine as long as you `return false` from them. A reassigned handler that returns `false` cancels presses on text fields too, so they never take focus.

## Debug console

For on-device troubleshooting, call `showDebug()` once in `setup()`, then log:

- `debug(message)`, `debugWarn(message)`, `debugError(message)`
- `hideDebug()`, `toggleDebug()`

Most useful for camera, NFC, BLE, and permission troubleshooting. Use sparingly in finished examples.

## Desktop QR and device detection

`showDesktopQr(options?)` shows a floating QR code of the current page on **desktop only** and does nothing on phones, so it can stay in a sketch: open the sketch on a laptop, scan, test on the phone. `setQrUrl(url)` points it elsewhere; `hideDesktopQr()` removes it. Options: `url`, `position` (`'top-right'` default / `'top-left'` / `'bottom-right'` / `'bottom-left'`), `size` (px, default 180), `label`, `closable`, `rememberDismiss`, `share` (after `shareSetup()` the QR carries the room join link; `false` opts out). The QR library loads from a CDN only when shown on desktop.

In the p5.js Web Editor the QR encodes the sketch's Present link (`https://editor.p5js.org/<user>/full/<id>`), so the phone gets the last *saved* version: save before scanning. An unsaved sketch shows no QR. Don't guard the call with `location.protocol === 'https:'` or `window.self === window.top`: both are false in the Web Editor and hide the QR there.

`window.isMobile` / `window.isDesktop` are booleans set when the library loads (user agent + touch + coarse-pointer checks, including iPadOS with a Mac user agent). Use them for desktop-only hints; gate hardware reads on the `*Enabled` flags, not on `isMobile`.

```javascript
function setup() {
  createCanvas(windowWidth, windowHeight);
  enableMicTap('Tap to start');
  showDesktopQr({ label: 'Scan to open on your phone' });
}
```

## Platform support matrix

| Feature | iOS Safari | Android Chrome |
| --- | --- | --- |
| Motion sensors | ✓ (permission tap required) | ✓ (no prompt; still use the tap, see Troubleshooting) |
| Microphone | ✓ | ✓ |
| Sound output | ✓ | ✓ |
| Speech recognition | Web Speech API support varies | ✓ |
| Camera | ✓ | ✓ |
| Vibration | ✗ (API absent) | ✓ |
| Torch / flashlight | ✓ (17.4+) | ✓ |
| NFC | ✗ | ✓ (HTTPS) |
| GPS / geolocation | ✓ (HTTPS, user gesture) | ✓ (HTTPS, user gesture) |
| Bluetooth BLE | ✗ (use Bluefy app) | ✓ (HTTPS) |
| Share (PartyServer) | ✓ (WebSocket) | ✓ (WebSocket) |
| Screen wake lock (browser API) | ✓ (16.4+, tap for the first request) | ✓ |

All hardware requires a secure context (HTTPS or localhost).

## Troubleshooting

- **Permission never fires / `*Enabled` stays false** — the request must run inside a user gesture. Confirm you used an `enable*` activation UI and did not call it on load. On iOS a single gesture only grants one activation window, so combine features with one `enablePermissions*` call.
- **Motion works on GitHub Pages but not in the p5.js Web Editor on Android** — since Chrome 153, Chrome pauses motion in an iframe until the sketch has focus. p5-phone 1.15.3 gives it focus on the motion tap; 1.15.4+ on any p5-phone tap and any later tap or click on the sketch. Load `p5-phone@1.15.4` or later and start every motion sketch with a p5-phone tap, even though Android shows no prompt.
- **In the p5.js Web Editor (an iframe)** — motion, mic, sound, speech, camera, torch, GPS, Bluetooth, Share and vibration work after the p5-phone tap. `keyPressed()` works after a tap or click on the sketch (with `lockGestures()`, p5-phone 1.15.4+). NFC and the screen wake lock never work there: host those sketches on their own page (GitHub Pages).
- **ML5 throws about `_incrementPreload` / preload with p5.js 2** — add the preload-counter polyfill shim before loading ml5 (see Camera section).
- **ML5: `Cannot read properties of null (reading 'estimateHands')`** — `detectStart()` ran before the model loaded. In a p5 sketch, call it in ml5's ready callback, not after `await` (see Camera section).
- **Motion (or the mic) never starts after adding a BLE or Share button** — a second `enable*` call removed the first one's UI. Start BLE and Share from `userSetupComplete()` (see Combining features).
- **Torch does nothing** — check `isTorchSupported()` and `window.torchError`. The torch needs HTTPS and a phone with a rear flash. iPhones need iOS 17.4 or later.
- **NFC does nothing** — NFC is Android Chrome + HTTPS only; check `window.nfcStatus`.
- **GPS hangs on "Acquiring…" or times out** — cold start can take 5-30s, longer indoors; move outdoors, retry, and confirm OS-level Location Services is on. `window.geoStatus` tells you which state you're in.
- **GPS denied even after tapping Allow** — the OS-level Location Services toggle (iOS Settings → Privacy & Security → Location Services; Android Settings → Location) must also be on; in-app browsers (Instagram/Facebook) usually fail — open in Safari/Chrome.
- **BLE won't connect on iPhone** — Web Bluetooth is unavailable in iOS Safari/Chrome; use the Bluefy app.
- **Share won't connect** — confirm `shareSetup({ host })` uses the deployed `*.workers.dev` URL (https), `wrangler deploy` succeeded, and the room name matches across devices.
- **Touch callbacks never run** — `touchStarted/Moved/Ended` are no-ops in p5.js 2; switch to `mousePressed/mouseDragged/mouseReleased`.
- **Tilt barely moves anything, or degree thresholds never trigger** — `rotationX/Y/Z` are in radians. Call `angleMode(DEGREES)` in `setup()`.
- **`mouseIsPressed` is false while a finger is still down** — p5 sets it false when any one finger lifts. Test `touches.length > 0` instead.
- **Mic example throws in preview** — don't call `p5.Amplitude.setInput(mic)` before `window.micEnabled`. `mic.getLevel is not a function` means p5.sound 0.3.x: use `mic.disconnect(); mic.connect(amplitude);` then `amplitude.getLevel()`.
- **Screen dims or locks during a motion, audio, or GPS sketch** — only touches reset the auto-lock timer. Hold a Screen Wake Lock (see that section), requested from `mouseReleased()`.
- **Mic level stays at 0** — check `window.micOpen`. `micEnabled` is `true` even when the microphone was denied or no input exists.

## Answering questions

- Explain the browser-permission reason, especially iOS transient user activation.
- Distinguish sensors, mic, sound-only, speech, camera, vibration, torch, NFC, GPS, BLE, and Share permissions/connections.
- Mention HTTPS requirements for mobile hardware.
- Mention p5.js 2 event changes when touch callbacks are involved.
- Flag browser/device limits clearly: NFC is Android Chrome only; vibration is unsupported on iOS; BLE needs Bluefy on iOS; speech recognition depends on Web Speech API support. The torch works on both iPhone (iOS 17.4+) and Android, with `isTorchSupported()` as the runtime check.
- Point to the bundled examples under `examples/` when useful — feature folders include `movement/`, `microphone/`, `sound/`, `touch/`, `vibration/`, `camera/`, `torch/`, `nfc/`, `geo/`, `ble/`, `wakelock/`, and `combined/`, plus `ml5/`, `UIStyles/`, and `UXcompare/`.
- When migrating examples to the p5 Web Editor, follow the web-editor batch-sync workflow in `docs/web-editor/` and record links in `webeditorLinks.md`.

## Example quality checklist

Before finishing generated code, confirm:

- `lockGestures()` is called in `setup()`.
- The permission request happens from a user-activation path (tap, button, banner, canvas, or custom element).
- Hardware data is read only after the matching `window.*Enabled` flag is true.
- The HTML includes the needed dependencies and no unused heavy libraries.
- p5.js 2-compatible `mouse*` callbacks are used (not p5 1.x touch callbacks).
- Tilt sketches call `angleMode(DEGREES)` in `setup()` before using `rotationX/Y/Z` as degrees.
- Multi-finger sketches test `touches.length`, not `mouseIsPressed`, for whether a finger is down.
- Text and canvas output fit mobile screens.
- Asset-dependent examples either include the assets or clearly document that the user must upload them.
- ML5 camera examples include the p5 2 compatibility shim and use `PhoneCamera` mapping helpers.
